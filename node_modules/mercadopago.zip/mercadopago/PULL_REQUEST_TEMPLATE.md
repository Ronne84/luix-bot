## Cambios realizados para el feature:
 * item 1

## Cambios generales
 * item 1
 
## Issues cerrados
 * Closes #XX
 

## Checklist validación PR:

- [ ] Título y descripción clara del PR
- [ ] Tests de mi funcionalidad 
- [ ] Documentación de mi funcionalidad
- [ ] Tests ejecutados y pasados
- [ ] Branch Coverage >= 80%
