module.exports = require('./lib/mercadopago.js');
